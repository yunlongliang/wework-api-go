# MpArticleMsg

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Title** | **string** |  | [optional] [default to null]
**ThumbMediaId** | **string** |  | [optional] [default to null]
**Author** | **string** |  | [optional] [default to null]
**ContentSourceUrl** | **string** |  | [optional] [default to null]
**Content** | **string** |  | [optional] [default to null]
**Digest** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


