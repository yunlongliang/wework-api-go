# GroupchatTransferReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ChatIdList** | **[]string** |  | [optional] [default to null]
**NewOwner** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


