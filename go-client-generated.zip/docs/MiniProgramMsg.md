# MiniProgramMsg

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Appid** | **string** |  | [optional] [default to null]
**Page** | **string** |  | [optional] [default to null]
**Title** | **string** |  | [optional] [default to null]
**Description** | **string** |  | [optional] [default to null]
**EmphasisFirstItem** | **bool** |  | [optional] [default to null]
**ContentItem** | **[]interface{}** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


