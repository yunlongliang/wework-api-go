# GetGroupmsgListV2Req

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ChatType** | **string** |  | [optional] [default to null]
**StartTime** | **int32** |  | [optional] [default to null]
**EndTime** | **int32** |  | [optional] [default to null]
**Creator** | **string** |  | [optional] [default to null]
**FilterType** | **int32** | 创建人类型。0：企业发表 1：个人发表 2：所有，包括个人创建以及企业创建，默认情况下为所有类型 | [optional] [default to null]
**Limit** | **int32** |  | [optional] [default to null]
**Cursor** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


