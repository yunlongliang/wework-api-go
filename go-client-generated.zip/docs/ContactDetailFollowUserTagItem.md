# ContactDetailFollowUserTagItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**GroupName** | **string** |  | [optional] [default to null]
**TagName** | **string** |  | [optional] [default to null]
**TagId** | **string** |  | [optional] [default to null]
**Type_** | **int32** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


