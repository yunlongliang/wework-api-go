# BatchGetresultRsp

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Errmsg** | **string** |  | [optional] [default to null]
**Errcode** | **int32** |  | [optional] [default to null]
**Status** | **int32** |  | [optional] [default to null]
**Type_** | **string** |  | [optional] [default to null]
**Total** | **int32** |  | [optional] [default to null]
**Percentage** | **int32** |  | [optional] [default to null]
**Result** | **[]interface{}** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


