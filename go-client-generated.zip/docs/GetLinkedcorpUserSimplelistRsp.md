# GetLinkedcorpUserSimplelistRsp

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Errcode** | **int32** |  | [optional] [default to null]
**Errmsg** | **string** |  | [optional] [default to null]
**Userlist** | **interface{}** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


