# UpdateUserReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Userid** | **string** |  | [optional] [default to null]
**Name** | **string** |  | [optional] [default to null]
**Department** | **[]int32** |  | [optional] [default to null]
**Order** | **[]int32** |  | [optional] [default to null]
**Position** | **string** |  | [optional] [default to null]
**Mobile** | **string** |  | [optional] [default to null]
**Gender** | **int32** |  | [optional] [default to null]
**Email** | **string** |  | [optional] [default to null]
**IsLeaderInDept** | **[]int32** |  | [optional] [default to null]
**Enable** | **int32** |  | [optional] [default to null]
**AvatarMediaid** | **string** |  | [optional] [default to null]
**Telephone** | **string** |  | [optional] [default to null]
**Alias** | **string** |  | [optional] [default to null]
**Address** | **string** |  | [optional] [default to null]
**MainDepartment** | **int32** |  | [optional] [default to null]
**Extattr** | [***ExtAttrs**](ExtAttrs.md) |  | [optional] [default to null]
**ExternalPosition** | **string** |  | [optional] [default to null]
**ExternalProfile** | [***ExternalProfile**](ExternalProfile.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


