# GetGroupchatStatisticReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DayBeginTime** | **int32** |  | [optional] [default to null]
**DayEndTime** | **int32** |  | [optional] [default to null]
**OwnerFilter** | **interface{}** |  | [optional] [default to null]
**OrderBy** | **int32** |  | [optional] [default to null]
**OrderAsc** | **int32** |  | [optional] [default to null]
**Offset** | **int32** |  | [optional] [default to null]
**Limit** | **int32** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


