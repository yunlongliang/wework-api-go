# UpdateTaskcardReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Userid** | **[]string** |  | [optional] [default to null]
**Agentid** | **int32** |  | [optional] [default to null]
**TaskId** | **string** |  | [optional] [default to null]
**ReplaceName** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


