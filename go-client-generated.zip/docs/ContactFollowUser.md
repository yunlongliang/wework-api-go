# ContactFollowUser

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Userid** | **string** |  | [optional] [default to null]
**Remark** | **string** |  | [optional] [default to null]
**Description** | **string** |  | [optional] [default to null]
**Createtime** | **int32** |  | [optional] [default to null]
**RemarkCorpName** | **string** |  | [optional] [default to null]
**OperUserid** | **string** |  | [optional] [default to null]
**AddWay** | **int32** |  | [optional] [default to null]
**State** | **string** |  | [optional] [default to null]
**RemarkMobiles** | **[]string** |  | [optional] [default to null]
**Tags** | **[]interface{}** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


