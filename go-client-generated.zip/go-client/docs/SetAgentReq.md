# SetAgentReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Agentid** | **int32** |  | [optional] [default to null]
**ReportLocationFlag** | **int32** |  | [optional] [default to null]
**LogoMediaid** | **string** |  | [optional] [default to null]
**Name** | **string** |  | [optional] [default to null]
**Description** | **string** |  | [optional] [default to null]
**RedirectDomain** | **string** |  | [optional] [default to null]
**Isreportenter** | **int32** |  | [optional] [default to null]
**HomeUrl** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


