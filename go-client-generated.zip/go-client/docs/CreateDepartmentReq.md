# CreateDepartmentReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | 部门名称。同一个层级的部门名称不能重复。长度限制为1~32个字符，字符不能包括\\:?”&lt;&gt;｜ | [optional] [default to null]
**NameEn** | **string** |  | [optional] [default to null]
**Parentid** | **int32** |  | [optional] [default to null]
**Order** | **int32** |  | [optional] [default to null]
**Id** | **int32** | 部门id，32位整型，指定时必须大于1。若不填该参数，将自动生成id | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


