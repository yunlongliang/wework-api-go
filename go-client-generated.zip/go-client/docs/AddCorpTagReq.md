# AddCorpTagReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**GroupId** | **string** |  | [optional] [default to null]
**GroupName** | **string** |  | [optional] [default to null]
**Order** | **int32** |  | [optional] [default to null]
**Tag** | **[]interface{}** |  | [optional] [default to null]
**Agentid** | **int32** | 授权方安装的应用agentid。仅旧的第三方多应用套件需要填此参数 | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


