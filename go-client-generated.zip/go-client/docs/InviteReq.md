# InviteReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**User** | **[]string** |  | [optional] [default to null]
**Party** | **[]string** |  | [optional] [default to null]
**Tag** | **[]string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


