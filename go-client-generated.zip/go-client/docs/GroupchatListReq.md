# GroupchatListReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StatusFilter** | **int32** | 客户群跟进状态过滤。0 - 所有列表(即不过滤);1 - 离职待继承;2 - 离职继承中;3 - 离职继承完成;默认为0 | [optional] [default to null]
**OwnerFilter** | **interface{}** |  | [optional] [default to null]
**Cursor** | **string** |  | [optional] [default to null]
**Limit** | **int32** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


