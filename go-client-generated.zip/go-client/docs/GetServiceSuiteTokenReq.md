# GetServiceSuiteTokenReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SuiteId** | **string** |  | [optional] [default to null]
**SuiteSecret** | **string** |  | [optional] [default to null]
**SuiteTicket** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


