# GetContactWayRsp

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Errmsg** | **string** |  | [optional] [default to null]
**Errcode** | **int32** |  | [optional] [default to null]
**ContactWay** | **interface{}** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


