# ResignedTransferCustomerReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HandoverUserid** | **string** |  | [optional] [default to null]
**TakeoverUserid** | **string** |  | [optional] [default to null]
**ExternalUserid** | **[]string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


