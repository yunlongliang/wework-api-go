# GetMomentTaskReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MomentId** | **string** |  | [optional] [default to null]
**Cursor** | **string** |  | [optional] [default to null]
**Limit** | **int32** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


