# AddGroupWelcomeTemplateReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Text** | **interface{}** |  | [optional] [default to null]
**Image** | **interface{}** |  | [optional] [default to null]
**Link** | **interface{}** |  | [optional] [default to null]
**Miniprogram** | **interface{}** |  | [optional] [default to null]
**Agentid** | **int32** | 授权方安装的应用agentid。仅旧的第三方多应用套件需要填此参数 | [optional] [default to null]
**Notify** | **int32** | 是否通知成员将这条入群欢迎语应用到客户群中，0-不通知，1-通知， 不填则通知 | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


