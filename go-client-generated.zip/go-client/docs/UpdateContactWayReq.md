# UpdateContactWayReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ConfigId** | **string** |  | [optional] [default to null]
**Remark** | **string** |  | [optional] [default to null]
**SkipVerify** | **bool** |  | [optional] [default to null]
**Style** | **int32** |  | [optional] [default to null]
**State** | **string** |  | [optional] [default to null]
**User** | **[]string** |  | [optional] [default to null]
**Party** | **[]int32** |  | [optional] [default to null]
**ExpiresIn** | **int32** | 临时会话二维码有效期，以秒为单位 | [optional] [default to null]
**ChatExpiresIn** | **int32** |  | [optional] [default to null]
**Unionid** | **string** |  | [optional] [default to null]
**Conclusions** | **interface{}** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


