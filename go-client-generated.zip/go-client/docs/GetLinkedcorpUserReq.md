# GetLinkedcorpUserReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Userid** | **string** | 该字段用的是互联应用可见范围接口返回的userids参数，用的是 CorpId + ’/‘ + USERID 拼成的字符串; \&quot;CORPID/USERID\&quot; | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


