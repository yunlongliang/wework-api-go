# GetMomentListReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartTime** | **int32** | 朋友圈记录开始时间。Unix时间戳 | [optional] [default to null]
**EndTime** | **int32** | 朋友圈记录结束时间。Unix时间戳 | [optional] [default to null]
**Creator** | **string** |  | [optional] [default to null]
**FilterType** | **int32** | 朋友圈类型。0：企业发表 1：个人发表 2：所有，包括个人创建以及企业创建，默认情况下为所有类型 | [optional] [default to null]
**Cursor** | **string** |  | [optional] [default to null]
**Limit** | **int32** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


