# ExternalContact

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExternalUserid** | **string** |  | [optional] [default to null]
**Name** | **string** |  | [optional] [default to null]
**Position** | **string** |  | [optional] [default to null]
**Avatar** | **string** |  | [optional] [default to null]
**CorpName** | **string** |  | [optional] [default to null]
**CorpFullName** | **string** |  | [optional] [default to null]
**Type_** | **int32** |  | [optional] [default to null]
**Gender** | **int32** |  | [optional] [default to null]
**Unionid** | **string** |  | [optional] [default to null]
**ExternalProfile** | **interface{}** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


