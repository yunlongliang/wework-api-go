# GetServiceCorpTokenReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AuthCorpid** | **string** | 授权方corpid | [optional] [default to null]
**PermanentCode** | **string** | 永久授权码，通过get_permanent_code获取 | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


