# GetLinkedcorpDepartmentListReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DepartmentId** | **string** | 该字段用的是互联应用可见范围接口返回的department_ids参数，用的是 linkedid + ’/‘ + department_id 拼成的字符串 | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


