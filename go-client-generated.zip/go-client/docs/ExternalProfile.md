# ExternalProfile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExternalCorpName** | **string** |  | [optional] [default to null]
**WechatChannels** | **interface{}** |  | [optional] [default to null]
**ExternalAttr** | [**[]ExtAttr**](ExtAttr.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


